# Guinea Pig — App Store & Google Play Pre-Submission Checklist

_Based on Apple App Store Review Guidelines and Google Play policies current as of 2026.
Store rules change; re-check before each submission. This is practical guidance, not legal advice._

---

## 🔴 PRIORITY 1 — PAYMENTS (highest rejection risk — decide before iOS submit)

**The rule:** Digital goods/services *consumed inside the app* → must use Apple IAP /
Google Play Billing. Physical goods & *real-world services* → must use external payment
(Stripe) and must NOT use IAP. Getting it backwards is a rejection in either direction.

**Guinea Pig's exposure (grey zone):**
- [ ] Model £4.99/mo subscription — unlocks in-app "apply" ability → **leans toward needing IAP on iOS**
- [ ] Provider £14.99 fee — unlocks profile visibility (in-app feature) → **leans toward needing IAP on iOS**

**Actions:**
- [ ] DECIDE the iOS payment approach before submitting (IAP vs external vs restructure)
- [ ] Consider asking Apple App Review directly (or a specialist) — don't burn attempts guessing
- [ ] Android/UK: don't assume Stripe is automatically fine — UK/EU external-billing rules & fees still in flux in 2026
- [ ] Whatever you choose: show full price, renewal terms, and cancellation BEFORE the user pays
- [ ] Make purchase/subscribe flows fully testable by the reviewer (sandbox OK)
- [ ] Add a "Restore Purchases" path if you use IAP

---

## 🔴 PRIORITY 2 — ACCOUNT DELETION (commonly missed, hard requirement both stores)

- [ ] User can **initiate account deletion from inside the app** (Settings) — NOT email-only
- [ ] Deletion actually removes/anonymises their data (tie to your data-retention policy)
- [ ] Verification selfies deleted on account deletion

---

## 🟡 PRIORITY 3 — USER-GENERATED CONTENT SAFETY (Apple 1.2 / Google UGC)

You have reports + a moderation queue. Confirm the full set:
- [ ] **EULA / Terms** must be agreed at signup (active acceptance)
- [ ] Terms explicitly prohibit objectionable content & abusive behaviour
- [ ] **Report** action on content and profiles (✓ you have reports)
- [ ] **Block user** capability — CONFIRM THIS EXISTS (often the missing piece)
- [ ] Content **filtering** (automated or manual review queue — ✓ you have moderation)
- [ ] Commit to acting on reports within **24 hours** (state this in review notes)
- [ ] **Published contact info** (support email visible in-app and store listing)

---

## 🟡 PRIORITY 4 — PRIVACY

- [ ] Privacy policy link in **store listing** (App Store Connect + Play Console)
- [ ] Privacy policy also **accessible inside the app** (Settings/About) — if hidden, treated as missing
- [ ] **Google Data Safety form** completed and **consistent with the privacy policy** (mismatch → suspension)
- [ ] **Apple Privacy "nutrition labels"** declared, matching what you actually collect + third-party SDKs
- [ ] Declare all data flows: account, location, selfie, payments (Stripe), email (Resend), media (Cloudinary), analytics
- [ ] **Permission strings** clearly explain WHY:
  - [ ] Camera — "to take your verification selfie"
  - [ ] Location — "to show stylists/models near you"
- [ ] Camera/location permission requested **in-context** (when the feature is used), not at launch
- [ ] Explain data retention + how users revoke consent / request deletion

---

## 🟡 PRIORITY 5 — APP COMPLETENESS (Apple 2.1 — ~40% of all rejections)

- [ ] No crashes on supported devices (test on real device, not just simulator)
- [ ] No placeholder / "coming soon" / broken links
- [ ] **Backend live and fast during review** (Supabase up, not paused)
- [ ] **Demo accounts in Review Notes** — BOTH a Model and a Provider, already verified/subscribed
- [ ] Review Notes explain non-obvious flows: verification selfie, payment/subscription, how model & provider connect
- [ ] Whitelist / confirm backend accepts Apple's reviewer IP ranges (a known gotcha)

---

## 🟢 PRIORITY 6 — METADATA & LISTING

- [ ] Screenshots show the **real app** (no mockups, no features that don't exist)
- [ ] Description doesn't promise features the app lacks
- [ ] **Age rating: 18+** (in-person meetings, adult context) — set honestly
- [ ] App name/subtitle/keywords not misleading or spammy
- [ ] Working **support URL** + privacy policy URL in listing
- [ ] Icon 512×512 (Play) + feature graphic 1024×500 (Play)

---

## 🟢 PRIORITY 7 — GOOGLE PLAY SPECIFICS

- [ ] Build targets **API level 35** (Android 15)
- [ ] **Developer account identity verified** (do early — not on submission day)
- [ ] Data Safety form complete + consistent with privacy policy
- [ ] Play Integrity API considered if needed

---

## 🟢 PRIORITY 8 — IN-PERSON SAFETY FRAMING (marketplace/meeting apps)

Because users meet in person, reviewers look for safety posture:
- [ ] Verification of identity (✓ you have this — highlight it in review notes)
- [ ] Reviews/ratings for accountability (✓)
- [ ] Reporting + blocking (see UGC section)
- [ ] Safety guidance/consent before booking (✓ your consent gate)
- [ ] Frame these clearly in Review Notes as your trust-and-safety model

---

## PRE-SUBMIT DRY RUN (do this on a clean device every time)

1. [ ] Install → open → complete the main path (browse → apply → subscribe → verify → book)
2. [ ] Both roles: run the model journey AND the provider journey end-to-end
3. [ ] Find the privacy policy inside the app
4. [ ] Delete account from inside the app
5. [ ] Report content + block a user
6. [ ] Trigger each permission prompt and read the string
7. [ ] Confirm every paid flow is testable by someone who's never seen the app

---

## REVIEW NOTES TEMPLATE (paste into App Store Connect / Play Console)

> Guinea Pig is a UK two-sided marketplace connecting Models (who want beauty treatments)
> with Providers (beauty practitioners gaining experience). Treatments happen in person;
> Guinea Pig is an introduction platform.
>
> DEMO ACCOUNTS:
> - Model (verified + subscribed): [email] / [password]
> - Provider (verified + published): [email] / [password]
>
> KEY FLOWS TO TEST:
> - Model: browse stylists → apply → (subscribe £4.99/mo) → verify identity (selfie) → book
> - Provider: pay £14.99 verification → selfie → (admin approves) → shop goes live → set availability
>
> PAYMENTS: [State your chosen approach and why — e.g. "payments relate to a real-world
> beauty-services marketplace" OR "digital access uses IAP".] Test card / sandbox: [details]
>
> PERMISSIONS: Camera = verification selfie. Location = show nearby users.
>
> TRUST & SAFETY: identity verification, reviews, in-app report + block, 24h moderation
> response, consent gate before booking. Users are 18+.
>
> BACKEND: Supabase (live during review), Stripe (payments), Cloudinary (media), Resend (email).
```
