# Guinea Pig — Example Legal Documents (ILLUSTRATIVE DRAFTS)

> ## ⚠️ READ THIS FIRST — NOT LEGAL ADVICE
>
> These documents are **illustrative examples only**, generated to help you understand
> what these policies typically cover and to help you brief a solicitor. They are:
>
> - **NOT legal advice** and **NOT written by a lawyer**;
> - **NOT safe to publish or rely on as-is**;
> - **Incomplete** — real documents need facts specific to your company (registered
>   company number, registered address, data-retention periods, insurer requirements,
>   your actual dispute process, etc.);
> - Subject to **UK law you cannot contract out of** — e.g. under the Consumer Rights
>   Act 2015 and Unfair Contract Terms Act 1977 you **cannot exclude liability for death
>   or personal injury caused by negligence**. Any wording that appears to do so is void.
>
> **A qualified UK solicitor must review and adapt these before you go live.** Given your
> model (people who may be unqualified practising treatments on the public) and your
> handling of identity selfies, this is not optional.
>
> Placeholders appear in `[SQUARE BRACKETS]` — these need real values.

---

# 1. TERMS OF SERVICE (example)

**Guinea Pig — Terms of Service**
Last updated: `[DATE]`

## 1. Who we are

Guinea Pig is an online platform operated by `[COMPANY NAME] Ltd`, a company registered
in England and Wales (company number `[NUMBER]`), registered office `[ADDRESS]`
("**Guinea Pig**", "**we**", "**us**"). You can contact us at `[SUPPORT EMAIL]`.

## 2. What Guinea Pig is — and is not

2.1 Guinea Pig is an **introduction platform**. We connect:
- **Models** — people who wish to receive beauty treatments, often free or discounted; and
- **Providers** — people practising and developing beauty skills (for example students,
  trainees, or newly-qualified practitioners) who wish to gain experience.

2.2 **We are an intermediary only.** Any treatment is a private arrangement **between the
Model and the Provider**. Guinea Pig is **not a party** to that arrangement, does not
provide treatments, does not employ Providers, and does not supervise, control, or
guarantee any treatment, its quality, or its outcome.

2.3 **Providers may be unqualified.** You acknowledge that Providers on Guinea Pig are
**practising and may not hold professional qualifications, insurance, or licences**. This
is the core nature of the platform and you accept it when you use Guinea Pig.

## 3. Eligibility

3.1 You must be **18 or over** to use Guinea Pig.

3.2 You must provide accurate information and complete any verification we require
(including identity verification). We may refuse, suspend, or remove any account at our
discretion, including where verification fails or we suspect misuse.

## 4. Verification and fees

4.1 **Providers** pay a one-off verification fee of `£[AMOUNT]` and must complete identity
verification before their profile becomes visible.

4.2 **Models** pay a subscription of `£[AMOUNT]`/month and must complete identity
verification before they can apply for treatments.

4.3 Fees are described at the point of payment. Payments are processed by our payment
provider (Stripe); we do not store full card details. `[Refund terms — TO BE DRAFTED WITH
SOLICITOR: e.g. verification fees are non-refundable once verification is attempted;
subscription cancellation terms; statutory cancellation rights under the Consumer
Contracts Regulations 2013.]`

## 5. Treatments, consent and safety

5.1 Before each booking, the Model must complete the **consent process** (see the separate
Consent document). Booking confirms the Model understands the Provider is practising and
accepts the normal risks of a practice treatment.

5.2 **Prohibited treatments.** The following must **not** be offered or performed through
Guinea Pig: `[e.g. injectables, dermal fillers, chemical peels, laser, microblading, any
treatment requiring a medical or specialist licence — FINALISE WITH SOLICITOR/INSURER]`.

5.3 **Patch testing.** For treatments carrying allergy risk (for example `[lashes, spray
tan]`), a valid patch test may be required before the treatment can proceed.

5.4 Models are responsible for disclosing relevant health conditions, allergies, and
medications, and for not booking a treatment that is unsafe for them.

## 6. Liability

6.1 **Nothing in these Terms limits or excludes our liability for death or personal injury
caused by our negligence, for fraud, or for anything else that cannot be limited or
excluded by law.** (This reflects the Consumer Rights Act 2015 and Unfair Contract Terms
Act 1977.)

6.2 Subject to 6.1, because Guinea Pig is only an introduction platform and is not a party
to any treatment: `[LIABILITY POSITION — TO BE DRAFTED WITH SOLICITOR. This section must be
carefully worded and is exactly where legal review matters most. Do not rely on the example
wording below.]`
- We are not responsible for the acts, omissions, conduct, qualifications, or treatment
  outcomes of any Model or Provider.
- Any dispute about a treatment is between the Model and the Provider.

6.3 We provide the platform "as is" and do not guarantee it will be uninterrupted or
error-free.

## 7. Conduct and content

7.1 You agree not to misuse the platform, harass others, provide false information, or use
Guinea Pig for anything unlawful.

7.2 You retain rights in content you upload but grant us a licence to use it to operate the
platform. You must not upload content you do not have the right to share.

## 8. Reporting and moderation

8.1 You can report other users or content. We operate a moderation process and may warn,
suspend, or ban users. `[Describe your actual process.]`

## 9. Suspension and termination

We may suspend or terminate accounts for breach of these Terms or to protect users or the
platform. You may stop using Guinea Pig at any time; `[subscription cancellation terms].`

## 10. Changes

We may update these Terms; we will notify you of material changes. Continued use means you
accept the updated Terms.

## 11. Governing law

These Terms are governed by the law of England and Wales, and the courts of England and
Wales have exclusive jurisdiction. `[Confirm with solicitor.]`

---

# 2. PRIVACY POLICY (example)

**Guinea Pig — Privacy Policy**
Last updated: `[DATE]`

## 1. Who is responsible for your data

`[COMPANY NAME] Ltd` (company number `[NUMBER]`, `[ADDRESS]`) is the **data controller**
for personal data processed through Guinea Pig. Contact: `[PRIVACY EMAIL]`.
We are registered with the UK Information Commissioner's Office (ICO), registration number
`[ICO NUMBER]`.

## 2. What data we collect

- **Account data:** name, email, password (stored securely/hashed), role (Model/Provider).
- **Profile data:** profile photo, bio, and — for Models — attributes you choose to share
  `[e.g. hair/skin details]`; for Providers, shop details and portfolio images.
- **Identity verification data:** a **verification selfie** (a photo of you holding a note
  with your name). This is used solely to confirm you are a real person and to match your
  identity. `[See retention below — this is sensitive and must be handled carefully.]`
- **Location data:** an approximate location (from `[postcode / device location]`) used to
  show nearby Models/Providers. `[Confirm exactly what you collect and its precision.]`
- **Booking and messaging data:** treatments booked, availability, messages between users,
  reviews.
- **Payment data:** processed by **Stripe**. We receive confirmation of payment and limited
  details; we do **not** store full card numbers.
- **Technical data:** app/usage/diagnostic data `[specify].`

## 3. Why we use it (lawful bases)

`[The lawful basis for each purpose must be confirmed with a solicitor. Example mapping:]`
- To provide the service and process bookings — **performance of a contract**.
- To verify identity and keep the platform safe — **legitimate interests** / **legal
  obligation** as applicable.
- To process payments — **performance of a contract**.
- Marketing (if any) — **consent**.

**Special note on verification selfies:** a photo used to identify you may be treated as
**special category / biometric-adjacent data** depending on how it's used. `[Your solicitor
must confirm whether Article 9 UK GDPR conditions apply and what explicit consent / extra
safeguards are needed.]`

## 4. Who we share it with

- **Other users** — limited profile info (not your verification selfie, not your exact
  address/postcode).
- **Service providers (processors)** — e.g. Supabase (hosting/database), Stripe
  (payments), `[Cloudinary (media), Resend (email)]`, who process data on our instructions.
- **Authorities** — where required by law.

We do **not** sell your personal data.

## 5. How long we keep it

`[RETENTION SCHEDULE — TO BE DEFINED. Example approach:]`
- Account data: while your account is active and `[period]` after closure.
- **Verification selfies:** kept only as long as needed to verify you `[e.g. deleted within
  [X] days of approval, or retained [X] months for fraud-prevention]` — **define and
  minimise this; it is your highest-sensitivity data.**
- Messages/bookings/reviews: `[period].`

## 6. Where your data is stored

`[Confirm hosting region — e.g. EU/UK — and any transfers outside the UK and the safeguards
for them.]`

## 7. Your rights

Under UK GDPR you can request access, correction, deletion, restriction, portability, and
object to certain processing. To exercise these or to complain, contact `[PRIVACY EMAIL]`.
We will acknowledge complaints within **30 days**. You can also complain to the ICO
(ico.org.uk).

## 8. Security

We use measures including `[encryption in transit, access controls, row-level security,
private storage for verification selfies with time-limited access]`. No system is perfectly
secure, but we take protecting your data seriously.

## 9. Children

Guinea Pig is strictly for users **18 and over**.

## 10. Changes

We may update this policy and will notify you of material changes.

---

# 3. BOOKING CONSENT (example)

> Shown to the Model before each booking is confirmed. Each point should require an
> **active tick** (nothing pre-ticked), and the exact version the user agreed to should be
> recorded. `[Your solicitor should review this wording — it is central to your risk
> position.]`

**Before you book**

Guinea Pig connects you with people who are **practising their skills**. Providers on this
platform are **learners and may not be professionally qualified**. Treatments carry normal
risks, including reactions, irritation, or unsatisfactory results. Guinea Pig is a platform
that introduces members to each other and **does not provide treatments itself**.

Please confirm you understand:

- ☐ I understand the Provider is **practising and may not be qualified**.
- ☐ I am booking **voluntarily** and accept the **normal risks** of a practice treatment.
- ☐ I am **18 or over** and have **no condition that makes this treatment unsafe** for me.
- ☐ I understand Guinea Pig is an **introduction platform** and is **not responsible for the
  treatment**, which is arranged directly between me and the Provider.
- ☐ `[For allergy-risk treatments:] I confirm a valid patch test has been carried out where
  required.`

> **Important:** This consent does **not** remove your legal rights. Nothing here excludes
> liability for death or personal injury caused by negligence — that cannot be excluded by
> law.

---

## Notes for your solicitor briefing (checklist)

- Confirm the **limited company** is set up and insert real company details.
- Confirm **ICO registration** and insert the registration number.
- Confirm **insurance** (public liability + professional indemnity) — and whether the
  insurer requires specific ToS wording (prohibited treatments, patch tests, disclaimers).
- Define **data-retention periods**, especially for **verification selfies**.
- Confirm the **lawful basis** for each processing purpose, and whether verification selfies
  trigger **special-category / Article 9** obligations.
- Draft the **refund / cancellation** terms (Consumer Contracts Regulations 2013).
- Review the **liability section** — the most important part — given the "unqualified
  practitioner" model.
- Confirm the **prohibited-treatments list** with insurer and solicitor.
- Confirm your **complaints process** (required to acknowledge within 30 days).
