# Guinea Pig — Session Handover

_Use this to start a fresh chat with full context. Hand it to Claude at the start._

---

## HOW I WORK (read first)
- **Persona:** methodical, root-cause-first coder. Fix the first cause in a chain, not symptoms. Pivot instead of tinkering. Elegant code.
- **Format I want:** terse, numbered, **copy-paste-ready** commands/SQL blocks. One task at a time. Minimal forward-planning. Use the decision-button tool for choices.
- **Always remind me to add haptic feedback** when building new screens/interactions.
- **Recurring trap:** stale Metro bundles mask fixes. After ANY mobile change, reload with `npx expo start -c --dev-client` before concluding a fix failed.

## STACK / PATHS
- Mobile: React Native/Expo (Android-first, iOS planned), Expo Router, EAS. Runs via Metro tunnel on my phone.
- Backend: Supabase (Postgres/auth/storage/realtime), project `ptluekkhiopowuyvkgnd`.
- Admin: Next.js 16.2.7 / Vercel (App Router, Turbopack).
- Payments: Stripe (TEST mode). Media: Cloudinary. Email: Resend.
- Repo: github.com/mickeebee89/Guinea-pig (commit direct to main).
- Windows paths: repo root `C:\Users\micky\Documents\Guinea-pig` (admin app); mobile in `mobile\`.
- Run mobile: `cd C:\Users\micky\Documents\Guinea-pig\mobile` then `npx expo start -c --dev-client`.
- Deploy edge fn: from repo ROOT `npx supabase functions deploy <name>` (Docker-not-running warning is harmless).
- I work via Claude Code (terminal) + Supabase SQL editor + phone testing. I paste prompts/results/screenshots back. Claude Code paste-backs sometimes arrive empty — I re-paste in sections.

## KEY IDENTIFIERS
- Admin/provider "Micky B": user_id `ff06d568-8936-45fa-ad5f-0b88c150ec30` (micky.buckfield@gmail.com); providers.id `49d40aae-a830-41d1-bca8-0fbdb2695455`.
- Model test acct: `b0df9c2f-02c5-4fef-afb0-9b184c3b9130` (micky.buckfield@hotmail.co.uk, subscribed+verified).
- Provider test acct `nahitih259@bevriz.com`: user_id `517c2853-50bb-4e8f-87fe-d79311bc37c0`.
- Palette: gold #C2A14D, blush/softPink #F4DADC, off-white #FBF6F1, warmDark #3A302C, pinkVibrant #F45D9E, roseDark #A8862E.

## SCHEMA ANCHORS (verified against live DB)
- Bookings are `sessions` (not `bookings`). Model in sessions = `model_user_id` (also `model_id` col exists). Provider owner = `providers.user_id`; session→provider via `provider_id`→`providers.id`. All are auth.users ids.
- **`public.users` has NO FK to `auth.users`** — deleting the auth user does NOT cascade public.users; must delete it explicitly. CASCADE-from-users children hang off `public.users`.
- `blocks` table: blocker_id, blocked_id (both FK users, ON DELETE CASCADE), unique on the pair. Mutual block = either direction.
- `messages.body` (not content). British spelling `colour_hex`. No `profiles` table. `admins` table for admin status. `model_attributes` holds model profile data.
- RLS: use `authenticated` role. RESTRICTIVE policies AND with permissive ones (a permissive INSERT must also exist).

## PRICING (Stripe TEST mode — swap to LIVE before launch)
- Provider £14.99 one-off verification (first 100–200 free "Founding Providers"). Model £4.99/mo subscription.
- Both PAY-FIRST: Get Verified → pay → selfie → admin approves → unlock. Provider unlock = is_verified + is_published. Model = active subscription AND identity verification both required to apply (browse free).
- Admin approve() unlocks unconditionally (free-account override). Test card 4242 4242 4242 4242, 12/34, 123.

---

## ✅ DONE THIS SESSION

### Distance filters + model dashboard
- Model home + provider dashboard distance filters now have **'Any'** (no cap) as first + default chip.
- Model home renamed "Dashboard"; title-left + chat/notifications/avatar icons right.
- Model home: horizontal upcoming treatments (soonest first, count in title); search+filter relocated to mirror provider dashboard's "Nearby" section layout.
- Provider dashboard: verified-status now refreshes on focus via separate `isVerified` state (root cause was `if(!p) return p` dropping the update when provider was null at focus). Availability save now shows "Availability saved ✓".

### Email / domain (operational — DONE)
- Domain `guineapigapp.co.uk` bought via Cloudflare Registrar.
- Resend: domain added + verified, DNS auto-configured via Cloudflare (SPF/DKIM/DMARC).
- Supabase custom SMTP wired: host smtp.resend.com, port 465, user `resend`, sender `no-reply@guineapigapp.co.uk`. Emails send + deliver (spam-at-first is normal for new domain).
- 5 branded auth email templates drafted (file: guinea-pig-email-templates.html) — to paste into Supabase → Auth → Emails → Templates.
- Email confirmation stays OFF during testing — **re-enable before launch**.

### App Store / Play compliance ("THE REDS") — hard gates
- **RED #1 — Account deletion — ✅ DONE + DEPLOYED + TESTED.** Edge fn `delete-account` (own-id-only from JWT, FK-safe delete order, storage cleanup, explicit public.users delete before auth delete, best-effort). settings.tsx dialog fixed (removed fake "type DELETE"). Tested: all counts 0. Committed+pushed.
- **RED #2 — User blocking — ✅ DONE + TESTED (Parts 1–3).**
  - Part 1: handleBlock writes to correct `blocks` table (was `user_blocks`); `mobile/src/lib/blocks.ts` `getBlockedIds(userId)` returns mutual set; RLS enforced (blocks_insert_own/select_involved/delete_own + RESTRICTIVE messages_insert_not_blocked + sessions_insert_not_blocked). Enforcement tested (blocked send rejected). Committed+pushed.
  - Part 2: 6 surfaces filter getBlockedIds, fail-open (.catch→new Set()): model home, provider dashboard nearby, messages list, chat (shows "You can't message this user"), applications, provider profile Apply. Tested both ways.
  - Part 2b: auto-cancel pending/accepted bookings between pair on block + notify OTHER party only ("Booking cancelled", type `session_cancelled`, no mention of blocking). **BUILT, not yet fully tested.**
  - Part 3: settings.tsx "Blocked users" section (unblock own rows). Tested: unblock works, users reappear. NOTE: blocked names may show "User" if users RLS blocks cross-user read (public_profiles is the usual cross-user read path if needed).
  - Earlier post-unblock "breakage" (empty messages/stuck chat/empty availability) was **stale state — resolved by restart, not a real bug.**
- **RED #3 — In-app legal screens — PARTIAL.** settings.tsx has Terms/Community/Privacy links BUT they point to WRONG domain `guineapig.beauty/*` (should be `guineapigapp.co.uk/*`, likely 404). **PARKED — needs fixing + those URLs must serve live content.**

---

## 🔴 IMMEDIATE NEXT STEPS
1. **Finish testing Part 2b auto-cancel:** book between the (now-unblocked) pair → confirm/accept → block from chat → verify booking flips to `cancelled` both sides + blocked party gets "Booking cancelled" notification.
2. **Commit blocking Parts 2/2b/3** once auto-cancel tested: `git add -A && git commit -m "Blocking: filter 6 surfaces, auto-cancel bookings on block, unblock UI in settings" && git push`

## 📌 PARKED / SMALLER GAPS
- **Messages unread badge stale:** open a chat → back to messages list → still shows (1); only clears after going to dashboard and back. Needs unread refresh on focus.
- RED #3: fix legal links `guineapig.beauty` → `guineapigapp.co.uk` (and ensure URLs serve live content, or build in-app legal screens).
- Remaining store gates: 18+ age confirmation at signup, EULA/terms acceptance tick at signup, iOS camera/location permission strings.
- Paste 5 branded email templates into Supabase.

## 🔴 LAUNCH CHECKLIST (mostly operational, long lead times)
- **#1 rejection risk = PAYMENTS/IAP:** model sub + provider fee unlock in-app features → Apple may require IAP on iOS (grey zone). DECIDE before iOS submit; consider asking Apple App Review directly. Don't guess.
- Swap Stripe TEST→LIVE keys (mobile .env pk_live + edge fn STRIPE_SECRET_KEY sk_live).
- Re-enable email confirmation.
- ICO registration (~£47/yr Tier 1, self-serve) — do before processing real user data; add a data-complaints route (ack within 30 days, new rule 19 Jun 2026).
- Solicitor: review ToS/privacy/consent (unqualified-practitioner model + identity selfies = special-category/Article 9 risk; define selfie retention period). Ltd company done.
- Insurance: public liability + professional indemnity.
- Production EAS build tested off dev machine (currently Metro tunnel) + 2nd physical device.
- App strengths to highlight in store review notes: identity verification, reviews, in-app report + block, moderation queue, consent gate, 18+.

## OUTPUT FILES FROM THIS SESSION (in /mnt/user-data/outputs)
- guinea-pig-email-templates.html — 5 branded Supabase auth email templates.
- guinea-pig-example-policies.md — illustrative ToS/Privacy/Consent drafts (NOT legal advice, for solicitor briefing).
- guinea-pig-store-compliance-checklist.md — Apple + Google pre-submission checklist tailored to the app.
